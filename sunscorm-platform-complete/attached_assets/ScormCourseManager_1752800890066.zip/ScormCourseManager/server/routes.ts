import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs/promises";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  insertCompanySchema,
  insertCourseSchema,
  insertDispatchSchema,
  insertAnalyticsEventSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Configure multer for file uploads
  const upload = multer({
    dest: "uploads/",
    limits: {
      fileSize: 100 * 1024 * 1024, // 100MB limit
    },
    fileFilter: (req, file, cb) => {
      if (file.mimetype === 'application/zip' || file.originalname.endsWith('.zip')) {
        cb(null, true);
      } else {
        cb(new Error('Only ZIP files are allowed'));
      }
    }
  });

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard metrics
  app.get("/api/dashboard/metrics", isAuthenticated, async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  app.get("/api/dashboard/top-companies", isAuthenticated, async (req, res) => {
    try {
      const topCompanies = await storage.getTopPerformingCompanies();
      res.json(topCompanies);
    } catch (error) {
      console.error("Error fetching top companies:", error);
      res.status(500).json({ message: "Failed to fetch top companies" });
    }
  });

  app.get("/api/dashboard/recent-activity", isAuthenticated, async (req, res) => {
    try {
      const recentEvents = await storage.getRecentEvents(20);
      res.json(recentEvents);
    } catch (error) {
      console.error("Error fetching recent activity:", error);
      res.status(500).json({ message: "Failed to fetch recent activity" });
    }
  });

  // Company routes
  app.get("/api/companies", isAuthenticated, async (req, res) => {
    try {
      const companies = await storage.getAllCompanies();
      res.json(companies);
    } catch (error) {
      console.error("Error fetching companies:", error);
      res.status(500).json({ message: "Failed to fetch companies" });
    }
  });

  app.get("/api/companies/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const company = await storage.getCompany(id);
      if (!company) {
        return res.status(404).json({ message: "Company not found" });
      }
      res.json(company);
    } catch (error) {
      console.error("Error fetching company:", error);
      res.status(500).json({ message: "Failed to fetch company" });
    }
  });

  app.post("/api/companies", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertCompanySchema.parse(req.body);
      const company = await storage.createCompany(validatedData);
      
      // Log analytics event
      await storage.createAnalyticsEvent({
        eventType: "company_created",
        companyId: company.id,
        metadata: { name: company.name },
      });

      res.status(201).json(company);
    } catch (error) {
      console.error("Error creating company:", error);
      res.status(500).json({ message: "Failed to create company" });
    }
  });

  app.put("/api/companies/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const company = await storage.updateCompany(id, req.body);
      res.json(company);
    } catch (error) {
      console.error("Error updating company:", error);
      res.status(500).json({ message: "Failed to update company" });
    }
  });

  app.delete("/api/companies/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteCompany(id);
      res.json({ message: "Company deleted successfully" });
    } catch (error) {
      console.error("Error deleting company:", error);
      res.status(500).json({ message: "Failed to delete company" });
    }
  });

  // Course routes
  app.get("/api/courses", isAuthenticated, async (req, res) => {
    try {
      const courses = await storage.getAllCourses();
      res.json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.get("/api/courses/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const course = await storage.getCourse(id);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json(course);
    } catch (error) {
      console.error("Error fetching course:", error);
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });

  app.post("/api/courses/upload", isAuthenticated, upload.single('courseFile'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { title, description, standard, category, tags } = req.body;
      
      // Validate the uploaded file (simplified)
      const fileStats = await fs.stat(req.file.path);
      
      const courseData = {
        title: title || req.file.originalname.replace('.zip', ''),
        description: description || '',
        standard: standard || 'scorm2004',
        category: category || 'general',
        tags: tags ? JSON.parse(tags) : [],
        fileSize: fileStats.size,
        filePath: req.file.path,
        previewUrl: null,
      };

      const validatedData = insertCourseSchema.parse(courseData);
      const course = await storage.createCourse(validatedData);

      // Log analytics event
      await storage.createAnalyticsEvent({
        eventType: "course_uploaded",
        courseId: course.id,
        metadata: { title: course.title, standard: course.standard },
      });

      res.status(201).json(course);
    } catch (error) {
      console.error("Error uploading course:", error);
      res.status(500).json({ message: "Failed to upload course" });
    }
  });

  app.put("/api/courses/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const course = await storage.updateCourse(id, req.body);
      res.json(course);
    } catch (error) {
      console.error("Error updating course:", error);
      res.status(500).json({ message: "Failed to update course" });
    }
  });

  app.delete("/api/courses/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteCourse(id);
      res.json({ message: "Course deleted successfully" });
    } catch (error) {
      console.error("Error deleting course:", error);
      res.status(500).json({ message: "Failed to delete course" });
    }
  });

  // Dispatch routes
  app.get("/api/dispatches", isAuthenticated, async (req, res) => {
    try {
      const dispatches = await storage.getAllDispatches();
      res.json(dispatches);
    } catch (error) {
      console.error("Error fetching dispatches:", error);
      res.status(500).json({ message: "Failed to fetch dispatches" });
    }
  });

  app.get("/api/dispatches/company/:companyId", isAuthenticated, async (req, res) => {
    try {
      const { companyId } = req.params;
      const dispatches = await storage.getDispatchesByCompany(companyId);
      res.json(dispatches);
    } catch (error) {
      console.error("Error fetching company dispatches:", error);
      res.status(500).json({ message: "Failed to fetch company dispatches" });
    }
  });

  app.post("/api/dispatches", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertDispatchSchema.parse(req.body);
      const dispatch = await storage.createDispatch(validatedData);

      // Log analytics event
      await storage.createAnalyticsEvent({
        eventType: "dispatch_created",
        companyId: dispatch.companyId,
        courseId: dispatch.courseId,
        dispatchId: dispatch.id,
        metadata: { title: dispatch.title },
      });

      res.status(201).json(dispatch);
    } catch (error) {
      console.error("Error creating dispatch:", error);
      res.status(500).json({ message: "Failed to create dispatch" });
    }
  });

  app.put("/api/dispatches/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const dispatch = await storage.updateDispatch(id, req.body);
      res.json(dispatch);
    } catch (error) {
      console.error("Error updating dispatch:", error);
      res.status(500).json({ message: "Failed to update dispatch" });
    }
  });

  app.delete("/api/dispatches/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteDispatch(id);
      res.json({ message: "Dispatch deleted successfully" });
    } catch (error) {
      console.error("Error deleting dispatch:", error);
      res.status(500).json({ message: "Failed to delete dispatch" });
    }
  });

  // Analytics routes
  app.post("/api/analytics/events", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertAnalyticsEventSchema.parse(req.body);
      const event = await storage.createAnalyticsEvent(validatedData);
      res.status(201).json(event);
    } catch (error) {
      console.error("Error creating analytics event:", error);
      res.status(500).json({ message: "Failed to create analytics event" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
