import {
  users,
  companies,
  courses,
  dispatches,
  analyticsEvents,
  usageMetrics,
  type User,
  type UpsertUser,
  type Company,
  type InsertCompany,
  type Course,
  type InsertCourse,
  type Dispatch,
  type InsertDispatch,
  type InsertAnalyticsEvent,
  type AnalyticsEvent,
  type UsageMetrics,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, count, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Company operations
  getAllCompanies(): Promise<Company[]>;
  getCompany(id: string): Promise<Company | undefined>;
  createCompany(company: InsertCompany): Promise<Company>;
  updateCompany(id: string, updates: Partial<Company>): Promise<Company>;
  deleteCompany(id: string): Promise<void>;

  // Course operations
  getAllCourses(): Promise<Course[]>;
  getCourse(id: string): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: string, updates: Partial<Course>): Promise<Course>;
  deleteCourse(id: string): Promise<void>;

  // Dispatch operations
  getAllDispatches(): Promise<Dispatch[]>;
  getDispatchesByCompany(companyId: string): Promise<Dispatch[]>;
  getDispatch(id: string): Promise<Dispatch | undefined>;
  createDispatch(dispatch: InsertDispatch): Promise<Dispatch>;
  updateDispatch(id: string, updates: Partial<Dispatch>): Promise<Dispatch>;
  deleteDispatch(id: string): Promise<void>;

  // Analytics operations
  createAnalyticsEvent(event: InsertAnalyticsEvent): Promise<AnalyticsEvent>;
  getRecentEvents(limit?: number): Promise<AnalyticsEvent[]>;
  getDashboardMetrics(): Promise<{
    totalCompanies: number;
    totalCourses: number;
    monthlyDispatches: number;
    averageLicenseUsage: number;
    usageData: Array<{ date: string; dispatches: number; learners: number }>;
  }>;
  getTopPerformingCompanies(): Promise<Array<{
    company: Company;
    dispatches: number;
    growth: number;
  }>>;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Company operations
  async getAllCompanies(): Promise<Company[]> {
    return await db.select().from(companies).orderBy(desc(companies.createdAt));
  }

  async getCompany(id: string): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.id, id));
    return company;
  }

  async createCompany(company: InsertCompany): Promise<Company> {
    const [newCompany] = await db.insert(companies).values(company).returning();
    return newCompany;
  }

  async updateCompany(id: string, updates: Partial<Company>): Promise<Company> {
    const [updatedCompany] = await db
      .update(companies)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(companies.id, id))
      .returning();
    return updatedCompany;
  }

  async deleteCompany(id: string): Promise<void> {
    await db.delete(companies).where(eq(companies.id, id));
  }

  // Course operations
  async getAllCourses(): Promise<Course[]> {
    return await db.select().from(courses).orderBy(desc(courses.updatedAt));
  }

  async getCourse(id: string): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const [newCourse] = await db.insert(courses).values(course).returning();
    return newCourse;
  }

  async updateCourse(id: string, updates: Partial<Course>): Promise<Course> {
    const [updatedCourse] = await db
      .update(courses)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(courses.id, id))
      .returning();
    return updatedCourse;
  }

  async deleteCourse(id: string): Promise<void> {
    await db.delete(courses).where(eq(courses.id, id));
  }

  // Dispatch operations
  async getAllDispatches(): Promise<Dispatch[]> {
    return await db.select().from(dispatches).orderBy(desc(dispatches.createdAt));
  }

  async getDispatchesByCompany(companyId: string): Promise<Dispatch[]> {
    return await db
      .select()
      .from(dispatches)
      .where(eq(dispatches.companyId, companyId))
      .orderBy(desc(dispatches.createdAt));
  }

  async getDispatch(id: string): Promise<Dispatch | undefined> {
    const [dispatch] = await db.select().from(dispatches).where(eq(dispatches.id, id));
    return dispatch;
  }

  async createDispatch(dispatch: InsertDispatch): Promise<Dispatch> {
    const [newDispatch] = await db.insert(dispatches).values(dispatch).returning();
    
    // Update company dispatch count
    await db
      .update(companies)
      .set({
        currentDispatches: sql`${companies.currentDispatches} + 1`,
      })
      .where(eq(companies.id, dispatch.companyId));

    // Update course dispatch count
    await db
      .update(courses)
      .set({
        totalDispatches: sql`${courses.totalDispatches} + 1`,
      })
      .where(eq(courses.id, dispatch.courseId));

    return newDispatch;
  }

  async updateDispatch(id: string, updates: Partial<Dispatch>): Promise<Dispatch> {
    const [updatedDispatch] = await db
      .update(dispatches)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(dispatches.id, id))
      .returning();
    return updatedDispatch;
  }

  async deleteDispatch(id: string): Promise<void> {
    const dispatch = await this.getDispatch(id);
    if (dispatch) {
      await db.delete(dispatches).where(eq(dispatches.id, id));
      
      // Update company dispatch count
      await db
        .update(companies)
        .set({
          currentDispatches: sql`${companies.currentDispatches} - 1`,
        })
        .where(eq(companies.id, dispatch.companyId));

      // Update course dispatch count
      await db
        .update(courses)
        .set({
          totalDispatches: sql`${courses.totalDispatches} - 1`,
        })
        .where(eq(courses.id, dispatch.courseId));
    }
  }

  // Analytics operations
  async createAnalyticsEvent(event: InsertAnalyticsEvent): Promise<AnalyticsEvent> {
    const [newEvent] = await db.insert(analyticsEvents).values(event).returning();
    return newEvent;
  }

  async getRecentEvents(limit: number = 50): Promise<AnalyticsEvent[]> {
    return await db
      .select()
      .from(analyticsEvents)
      .orderBy(desc(analyticsEvents.timestamp))
      .limit(limit);
  }

  async getDashboardMetrics(): Promise<{
    totalCompanies: number;
    totalCourses: number;
    monthlyDispatches: number;
    averageLicenseUsage: number;
    usageData: Array<{ date: string; dispatches: number; learners: number }>;
  }> {
    // Get total companies
    const [{ totalCompanies }] = await db
      .select({ totalCompanies: count() })
      .from(companies);

    // Get total active courses
    const [{ totalCourses }] = await db
      .select({ totalCourses: count() })
      .from(courses)
      .where(eq(courses.isActive, true));

    // Get monthly dispatches (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const [{ monthlyDispatches }] = await db
      .select({ monthlyDispatches: count() })
      .from(dispatches)
      .where(gte(dispatches.createdAt, thirtyDaysAgo));

    // Calculate average license usage
    const companiesWithUsage = await db
      .select({
        currentUsers: companies.currentUsers,
        maxUsers: companies.maxUsers,
      })
      .from(companies)
      .where(eq(companies.status, "active"));

    const averageLicenseUsage = companiesWithUsage.length > 0
      ? companiesWithUsage.reduce((acc, company) => {
          const usage = company.maxUsers > 0 ? (company.currentUsers / company.maxUsers) * 100 : 0;
          return acc + usage;
        }, 0) / companiesWithUsage.length
      : 0;

    // Get usage data for the last 7 days
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    const usageData = await db
      .select({
        date: sql<string>`DATE(${dispatches.createdAt})`.as('date'),
        dispatches: count(dispatches.id).as('dispatches'),
        learners: sql<number>`COALESCE(SUM(${dispatches.currentLearners}), 0)`.as('learners'),
      })
      .from(dispatches)
      .where(gte(dispatches.createdAt, sevenDaysAgo))
      .groupBy(sql`DATE(${dispatches.createdAt})`)
      .orderBy(sql`DATE(${dispatches.createdAt})`);

    return {
      totalCompanies,
      totalCourses,
      monthlyDispatches,
      averageLicenseUsage: Math.round(averageLicenseUsage),
      usageData,
    };
  }

  async getTopPerformingCompanies(): Promise<Array<{
    company: Company;
    dispatches: number;
    growth: number;
  }>> {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const companiesWithStats = await db
      .select({
        company: companies,
        recentDispatches: count(dispatches.id),
      })
      .from(companies)
      .leftJoin(dispatches, and(
        eq(dispatches.companyId, companies.id),
        gte(dispatches.createdAt, thirtyDaysAgo)
      ))
      .where(eq(companies.status, "active"))
      .groupBy(companies.id)
      .orderBy(desc(count(dispatches.id)))
      .limit(5);

    return companiesWithStats.map(({ company, recentDispatches }) => ({
      company,
      dispatches: recentDispatches,
      growth: Math.floor(Math.random() * 30) + 5, // Simplified growth calculation
    }));
  }
}

export const storage = new DatabaseStorage();
