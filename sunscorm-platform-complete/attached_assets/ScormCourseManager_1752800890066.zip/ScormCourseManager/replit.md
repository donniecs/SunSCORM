# Sun-SCORM Platform

## Overview

Sun-SCORM is a comprehensive e-learning platform designed as a modern alternative to SCORM Cloud. The system provides SCORM content management, course dispatch creation, learning delivery, and analytics capabilities. It's built as a full-stack web application with a React frontend and Express.js backend, designed to handle enterprise-level SCORM content distribution and tracking.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Authentication**: Session-based authentication with Replit OAuth integration

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon serverless)
- **Authentication**: Passport.js with OpenID Connect for Replit OAuth
- **Session Storage**: PostgreSQL-backed sessions with connect-pg-simple
- **File Handling**: Multer for SCORM package uploads

### Database Design
The system uses a relational PostgreSQL schema with the following key entities:
- **Users**: Admin and company user accounts with role-based access
- **Companies**: Multi-tenant organizations with service tier limits
- **Courses**: SCORM content packages with metadata and standards support
- **Dispatches**: Licensed course distributions with learner tracking
- **Analytics Events**: Comprehensive activity and usage tracking
- **Usage Metrics**: Aggregated statistics for dashboard reporting

## Key Components

### Authentication System
- **Provider**: Replit OAuth with OpenID Connect
- **Session Management**: Server-side sessions stored in PostgreSQL
- **Role-Based Access**: Admin users manage the platform, company users manage their content
- **Security**: JWT tokens with proper validation and refresh mechanisms

### Course Management
- **Upload Processing**: ZIP file validation and SCORM package extraction
- **Standards Support**: SCORM 1.2, SCORM 2004, xAPI, and cMI5 compatibility
- **Metadata Extraction**: Automatic parsing of course manifests and properties
- **File Storage**: Organized storage system for course assets and content

### Dispatch System
- **License Management**: Configurable learner limits and expiration dates
- **URL Generation**: Secure launch URLs for course delivery
- **Progress Tracking**: Real-time learner progress and completion monitoring
- **Company Isolation**: Multi-tenant data separation and access control

### Analytics Engine
- **Event Tracking**: Comprehensive logging of user actions and system events
- **Dashboard Metrics**: Real-time statistics and usage summaries
- **Chart Visualization**: Custom canvas-based charts for data presentation
- **Report Generation**: Exportable reports and usage analytics

## Data Flow

### Course Upload Flow
1. User uploads SCORM ZIP package through the web interface
2. Server validates file type and size limits
3. Course metadata is extracted and stored in the database
4. Files are processed and stored in the organized file system
5. Course becomes available for dispatch creation

### Dispatch Creation Flow
1. Admin selects course and target company
2. System generates unique dispatch with license parameters
3. Secure launch URL is created with embedded authentication
4. Company receives access to the licensed content
5. Usage tracking begins upon first learner access

### Analytics Data Flow
1. User actions trigger event logging throughout the system
2. Events are stored with structured metadata for analysis
3. Background processes aggregate data for dashboard metrics
4. Real-time queries provide live statistics and charts
5. Scheduled reports generate usage summaries

## External Dependencies

### Database Services
- **Neon PostgreSQL**: Serverless PostgreSQL database hosting
- **Connection Pooling**: Built-in connection management for scalability

### Authentication Services
- **Replit OAuth**: Primary authentication provider
- **OpenID Connect**: Standard authentication protocol implementation

### UI Component Libraries
- **Radix UI**: Headless UI primitives for accessibility
- **Lucide React**: Icon system for consistent visual elements
- **TanStack Query**: Server state management and caching

### Development Tools
- **Vite**: Fast development server and build tool
- **TypeScript**: Type safety across frontend and backend
- **Drizzle Kit**: Database schema management and migrations

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with Express backend
- **Hot Reload**: Real-time code updates during development
- **Database Migrations**: Automated schema updates with Drizzle Kit

### Production Build
- **Frontend**: Static build optimized for CDN delivery
- **Backend**: Bundled Express server with ESM module support
- **Database**: Production PostgreSQL with connection pooling

### Scaling Considerations
- **Stateless Design**: Session storage in database for horizontal scaling
- **File Storage**: Prepared for object storage migration (S3-compatible)
- **Database**: Connection pooling and query optimization for performance
- **Caching**: Redis integration ready for session and data caching

### Security Measures
- **Authentication**: Secure OAuth flow with proper token validation
- **File Validation**: Strict SCORM package validation and sanitization
- **Access Control**: Role-based permissions and company data isolation
- **Session Security**: Secure cookie configuration and session expiration