import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  integer,
  boolean,
  real,
  serial,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").notNull().default("admin"), // admin, company_user
  companyId: varchar("company_id"), // null for admin users
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Companies table
export const companies = pgTable("companies", {
  id: varchar("id").primaryKey().notNull().default("gen_random_uuid()"),
  name: varchar("name").notNull(),
  email: varchar("email").notNull().unique(),
  serviceTier: varchar("service_tier").notNull().default("basic"), // basic, professional, enterprise
  maxUsers: integer("max_users").notNull().default(100),
  maxDispatches: integer("max_dispatches").notNull().default(500),
  currentUsers: integer("current_users").notNull().default(0),
  currentDispatches: integer("current_dispatches").notNull().default(0),
  logoUrl: varchar("logo_url"),
  status: varchar("status").notNull().default("active"), // active, suspended, inactive
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Courses table
export const courses = pgTable("courses", {
  id: varchar("id").primaryKey().notNull().default("gen_random_uuid()"),
  title: varchar("title").notNull(),
  description: text("description"),
  standard: varchar("standard").notNull(), // scorm12, scorm2004, xapi, cmi5
  category: varchar("category").notNull().default("general"),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  fileSize: integer("file_size").notNull().default(0),
  filePath: varchar("file_path").notNull(),
  previewUrl: varchar("preview_url"),
  totalDispatches: integer("total_dispatches").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Dispatches table
export const dispatches = pgTable("dispatches", {
  id: varchar("id").primaryKey().notNull().default("gen_random_uuid()"),
  companyId: varchar("company_id").notNull(),
  courseId: varchar("course_id").notNull(),
  title: varchar("title").notNull(),
  maxLearners: integer("max_learners"),
  currentLearners: integer("current_learners").notNull().default(0),
  expiresAt: timestamp("expires_at"),
  isActive: boolean("is_active").notNull().default(true),
  launchUrl: varchar("launch_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Analytics events table
export const analyticsEvents = pgTable("analytics_events", {
  id: serial("id").primaryKey(),
  eventType: varchar("event_type").notNull(), // dispatch_created, course_launched, user_registered, etc.
  companyId: varchar("company_id"),
  courseId: varchar("course_id"),
  dispatchId: varchar("dispatch_id"),
  userId: varchar("user_id"),
  metadata: jsonb("metadata"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Usage metrics table for tracking daily/monthly usage
export const usageMetrics = pgTable("usage_metrics", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  companyId: varchar("company_id"),
  totalDispatches: integer("total_dispatches").notNull().default(0),
  totalLearners: integer("total_learners").notNull().default(0),
  totalCourses: integer("total_courses").notNull().default(0),
  licenseUsagePercent: real("license_usage_percent").notNull().default(0),
});

// Relations
export const usersRelations = relations(users, ({ one }) => ({
  company: one(companies, {
    fields: [users.companyId],
    references: [companies.id],
  }),
}));

export const companiesRelations = relations(companies, ({ many }) => ({
  users: many(users),
  dispatches: many(dispatches),
}));

export const coursesRelations = relations(courses, ({ many }) => ({
  dispatches: many(dispatches),
}));

export const dispatchesRelations = relations(dispatches, ({ one }) => ({
  company: one(companies, {
    fields: [dispatches.companyId],
    references: [companies.id],
  }),
  course: one(courses, {
    fields: [dispatches.courseId],
    references: [courses.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertCompanySchema = createInsertSchema(companies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  currentUsers: true,
  currentDispatches: true,
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  totalDispatches: true,
});

export const insertDispatchSchema = createInsertSchema(dispatches).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  currentLearners: true,
});

export const insertAnalyticsEventSchema = createInsertSchema(analyticsEvents).omit({
  id: true,
  timestamp: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;
export type InsertDispatch = z.infer<typeof insertDispatchSchema>;
export type Dispatch = typeof dispatches.$inferSelect;
export type InsertAnalyticsEvent = z.infer<typeof insertAnalyticsEventSchema>;
export type AnalyticsEvent = typeof analyticsEvents.$inferSelect;
export type UsageMetrics = typeof usageMetrics.$inferSelect;
