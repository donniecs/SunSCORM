import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart3, TrendingUp } from "lucide-react";

interface ChartData {
  date: string;
  dispatches: number;
  learners: number;
}

interface AnalyticsChartProps {
  data: ChartData[];
  loading: boolean;
  title?: string;
  subtitle?: string;
}

export default function AnalyticsChart({ 
  data, 
  loading, 
  title = "Platform Usage Analytics",
  subtitle = "Track performance of your eLearning content"
}: AnalyticsChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!data || data.length === 0 || loading) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * window.devicePixelRatio;
    canvas.height = rect.height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    const width = rect.width;
    const height = rect.height;
    const padding = 40;
    const chartWidth = width - 2 * padding;
    const chartHeight = height - 2 * padding;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Get max values for scaling
    const maxDispatches = Math.max(...data.map(d => d.dispatches));
    const maxLearners = Math.max(...data.map(d => d.learners));
    const maxValue = Math.max(maxDispatches, maxLearners);

    if (maxValue === 0) return;

    // Draw grid lines
    ctx.strokeStyle = '#f3f4f6';
    ctx.lineWidth = 1;
    
    for (let i = 0; i <= 5; i++) {
      const y = padding + (i * chartHeight) / 5;
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();
    }

    // Draw dispatch line
    ctx.strokeStyle = '#2563eb';
    ctx.fillStyle = 'rgba(37, 99, 235, 0.1)';
    ctx.lineWidth = 3;
    
    ctx.beginPath();
    data.forEach((point, index) => {
      const x = padding + (index * chartWidth) / (data.length - 1);
      const y = padding + chartHeight - (point.dispatches * chartHeight) / maxValue;
      
      if (index === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });
    
    // Fill area under dispatches line
    const gradientDispatches = ctx.createLinearGradient(0, padding, 0, height - padding);
    gradientDispatches.addColorStop(0, 'rgba(37, 99, 235, 0.2)');
    gradientDispatches.addColorStop(1, 'rgba(37, 99, 235, 0.05)');
    
    ctx.lineTo(width - padding, height - padding);
    ctx.lineTo(padding, height - padding);
    ctx.closePath();
    ctx.fillStyle = gradientDispatches;
    ctx.fill();
    ctx.stroke();

    // Draw learners line
    ctx.strokeStyle = '#10b981';
    ctx.fillStyle = 'rgba(16, 185, 129, 0.1)';
    ctx.lineWidth = 3;
    
    ctx.beginPath();
    data.forEach((point, index) => {
      const x = padding + (index * chartWidth) / (data.length - 1);
      const y = padding + chartHeight - (point.learners * chartHeight) / maxValue;
      
      if (index === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });
    
    // Fill area under learners line
    const gradientLearners = ctx.createLinearGradient(0, padding, 0, height - padding);
    gradientLearners.addColorStop(0, 'rgba(16, 185, 129, 0.2)');
    gradientLearners.addColorStop(1, 'rgba(16, 185, 129, 0.05)');
    
    ctx.lineTo(width - padding, height - padding);
    ctx.lineTo(padding, height - padding);
    ctx.closePath();
    ctx.fillStyle = gradientLearners;
    ctx.fill();
    ctx.stroke();

    // Draw data points
    data.forEach((point, index) => {
      const x = padding + (index * chartWidth) / (data.length - 1);
      
      // Dispatch points
      const yDispatches = padding + chartHeight - (point.dispatches * chartHeight) / maxValue;
      ctx.fillStyle = '#2563eb';
      ctx.beginPath();
      ctx.arc(x, yDispatches, 4, 0, 2 * Math.PI);
      ctx.fill();
      
      // Learner points
      const yLearners = padding + chartHeight - (point.learners * chartHeight) / maxValue;
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(x, yLearners, 4, 0, 2 * Math.PI);
      ctx.fill();
    });

  }, [data, loading]);

  return (
    <Card className="h-full">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
              <BarChart3 className="w-5 h-5 mr-2 text-blue-600" />
              {title}
            </CardTitle>
            {subtitle && (
              <p className="text-sm text-gray-600 mt-1">{subtitle}</p>
            )}
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" className="bg-blue-50 text-blue-600 border-blue-200">
              7D
            </Button>
            <Button variant="outline" size="sm" className="text-gray-600 hover:bg-gray-100">
              30D
            </Button>
            <Button variant="outline" size="sm" className="text-gray-600 hover:bg-gray-100">
              90D
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="h-80">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : data && data.length > 0 ? (
          <div className="relative h-full">
            <canvas
              ref={canvasRef}
              className="w-full h-full"
              style={{ width: '100%', height: '100%' }}
            />
            {/* Legend */}
            <div className="absolute bottom-2 left-2 flex space-x-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                <span className="text-gray-700">Course Dispatches</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-gray-700">License Usage</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            <div className="text-center">
              <TrendingUp className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>No analytics data available</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
