import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Eye, MoreVertical, Edit, Trash2, Download, BookOpen } from "lucide-react";

interface Course {
  id: string;
  title: string;
  description?: string;
  standard: string;
  category: string;
  tags: string[];
  fileSize: number;
  previewUrl?: string;
  totalDispatches: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface CourseCardProps {
  course: Course;
  viewMode: "grid" | "list";
}

const standardColors = {
  scorm12: "bg-orange-100 text-orange-700",
  scorm2004: "bg-blue-100 text-blue-700",
  xapi: "bg-green-100 text-green-700",
  cmi5: "bg-purple-100 text-purple-700",
};

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
};

const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - date.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 1) return "1 day ago";
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 30) return `${Math.ceil(diffDays / 7)} weeks ago`;
  return date.toLocaleDateString();
};

export default function CourseCard({ course, viewMode }: CourseCardProps) {
  const standardColor = standardColors[course.standard as keyof typeof standardColors] || "bg-gray-100 text-gray-700";

  if (viewMode === "list") {
    return (
      <Card className="hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 flex-1">
              {/* Course Icon/Preview */}
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                <BookOpen className="w-8 h-8 text-white" />
              </div>
              
              {/* Course Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2 mb-1">
                  <h4 className="font-semibold text-gray-900 truncate">{course.title}</h4>
                  <Badge className={`text-xs ${standardColor}`}>
                    {course.standard.toUpperCase()}
                  </Badge>
                  {!course.isActive && (
                    <Badge variant="secondary" className="text-xs">Inactive</Badge>
                  )}
                </div>
                {course.description && (
                  <p className="text-sm text-gray-600 mb-2 line-clamp-1">{course.description}</p>
                )}
                <div className="flex items-center space-x-4 text-xs text-gray-500">
                  <span>{course.totalDispatches} dispatches</span>
                  <span>{formatFileSize(course.fileSize)}</span>
                  <span>Updated {formatDate(course.updatedAt)}</span>
                </div>
              </div>
              
              {/* Tags */}
              <div className="hidden lg:flex space-x-1">
                {course.tags.slice(0, 3).map((tag, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {tag}
                  </Badge>
                ))}
                {course.tags.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{course.tags.length - 3}
                  </Badge>
                )}
              </div>
            </div>

            {/* Actions */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <Eye className="w-4 h-4 mr-2" />
                  Preview
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </DropdownMenuItem>
                <DropdownMenuItem className="text-red-600">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="hover:shadow-lg transition-all duration-200 hover:-translate-y-1 overflow-hidden">
      {/* Course Preview */}
      <div className="w-full h-32 bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
        <BookOpen className="w-12 h-12 text-white" />
      </div>
      
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <Badge className={`text-xs ${standardColor}`}>
            {course.standard.toUpperCase()}
          </Badge>
          <div className="flex items-center space-x-1">
            <Eye className="w-3 h-3 text-gray-400" />
            <span className="text-xs text-gray-500">Preview</span>
          </div>
        </div>
        
        <h4 className="font-semibold text-gray-900 mb-1 line-clamp-1">{course.title}</h4>
        {course.description && (
          <p className="text-sm text-gray-600 mb-3 line-clamp-2">{course.description}</p>
        )}
        
        <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
          <span>{course.totalDispatches} dispatches</span>
          <span>Updated {formatDate(course.updatedAt)}</span>
        </div>
        
        {/* Tags */}
        <div className="flex flex-wrap gap-1 mb-3">
          {course.tags.slice(0, 2).map((tag, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {tag}
            </Badge>
          ))}
          {course.tags.length > 2 && (
            <Badge variant="outline" className="text-xs">
              +{course.tags.length - 2}
            </Badge>
          )}
        </div>

        {/* Actions */}
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" className="flex-1 text-xs">
            <Eye className="w-3 h-3 mr-1" />
            Preview
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <MoreVertical className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Download className="w-4 h-4 mr-2" />
                Download
              </DropdownMenuItem>
              <DropdownMenuItem className="text-red-600">
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardContent>
    </Card>
  );
}
