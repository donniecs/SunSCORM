import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Building, MoreVertical, Edit, Settings, Ban, Building2 } from "lucide-react";

interface Company {
  id: string;
  name: string;
  email: string;
  serviceTier: string;
  maxUsers: number;
  maxDispatches: number;
  currentUsers: number;
  currentDispatches: number;
  logoUrl?: string;
  status: string;
  createdAt: string;
  updatedAt: string;
}

interface CompanyTableProps {
  companies: Company[];
  loading: boolean;
  onRefresh: () => void;
}

const tierColors = {
  basic: "bg-gray-100 text-gray-700",
  professional: "bg-orange-100 text-orange-700",
  enterprise: "bg-blue-100 text-blue-700",
};

const statusColors = {
  active: "bg-green-100 text-green-700",
  suspended: "bg-red-100 text-red-700",
  inactive: "bg-gray-100 text-gray-700",
};

export default function CompanyTable({ companies, loading, onRefresh }: CompanyTableProps) {
  const [selectedCompany, setSelectedCompany] = useState<string | null>(null);

  const getUsagePercentage = (current: number, max: number): number => {
    return max > 0 ? Math.round((current / max) * 100) : 0;
  };

  const getUsageColor = (percentage: number): string => {
    if (percentage >= 90) return "bg-red-500";
    if (percentage >= 75) return "bg-orange-500";
    return "bg-green-500";
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/6"></div>
                  </div>
                  <div className="w-20 h-6 bg-gray-200 rounded"></div>
                  <div className="w-32 h-4 bg-gray-200 rounded"></div>
                  <div className="w-16 h-4 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (companies.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <Building2 className="w-16 h-16 mx-auto mb-4 text-gray-300" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No companies found</h3>
          <p className="text-gray-500 mb-6">Get started by adding your first company to the platform</p>
          <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
            Add First Company
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Company
                </TableHead>
                <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Service Tier
                </TableHead>
                <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  License Usage
                </TableHead>
                <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Monthly Dispatches
                </TableHead>
                <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </TableHead>
                <TableHead className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="bg-white divide-y divide-gray-200">
              {companies.map((company) => {
                const userUsagePercent = getUsagePercentage(company.currentUsers, company.maxUsers);
                const dispatchUsagePercent = getUsagePercentage(company.currentDispatches, company.maxDispatches);
                const maxUsagePercent = Math.max(userUsagePercent, dispatchUsagePercent);
                
                return (
                  <TableRow 
                    key={company.id} 
                    className="hover:bg-gray-50 transition-colors"
                  >
                    <TableCell className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center mr-3">
                          <Building className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{company.name}</div>
                          <div className="text-sm text-gray-500">{company.email}</div>
                        </div>
                      </div>
                    </TableCell>
                    
                    <TableCell className="px-6 py-4 whitespace-nowrap">
                      <Badge 
                        className={`text-xs ${
                          tierColors[company.serviceTier as keyof typeof tierColors] || tierColors.basic
                        }`}
                      >
                        {company.serviceTier.charAt(0).toUpperCase() + company.serviceTier.slice(1)}
                      </Badge>
                    </TableCell>
                    
                    <TableCell className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-3">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full transition-all duration-1000 ease-out ${getUsageColor(maxUsagePercent)}`}
                            style={{ width: `${maxUsagePercent}%` }}
                          ></div>
                        </div>
                        <span className="text-sm text-gray-600 min-w-max">
                          {company.currentUsers}/{company.maxUsers}
                        </span>
                      </div>
                    </TableCell>
                    
                    <TableCell className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex flex-col">
                        <span className="font-medium">{company.currentDispatches.toLocaleString()}</span>
                        <span className="text-xs text-gray-500">of {company.maxDispatches.toLocaleString()}</span>
                      </div>
                    </TableCell>
                    
                    <TableCell className="px-6 py-4 whitespace-nowrap">
                      <Badge 
                        className={`text-xs ${
                          statusColors[company.status as keyof typeof statusColors] || statusColors.inactive
                        }`}
                      >
                        {company.status.charAt(0).toUpperCase() + company.status.slice(1)}
                      </Badge>
                    </TableCell>
                    
                    <TableCell className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit Company
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Settings className="w-4 h-4 mr-2" />
                            Settings
                          </DropdownMenuItem>
                          {company.status === "active" ? (
                            <DropdownMenuItem className="text-red-600">
                              <Ban className="w-4 h-4 mr-2" />
                              Suspend
                            </DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem className="text-green-600">
                              <Building className="w-4 h-4 mr-2" />
                              Activate
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
