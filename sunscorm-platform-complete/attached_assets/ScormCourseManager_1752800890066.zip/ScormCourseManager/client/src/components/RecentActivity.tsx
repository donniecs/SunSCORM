import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  Clock,
  Building,
  BookOpen,
  Send
} from "lucide-react";

interface AnalyticsEvent {
  id: number;
  eventType: string;
  companyId?: string;
  courseId?: string;
  dispatchId?: string;
  metadata?: any;
  timestamp: string;
}

export default function RecentActivity() {
  const { data: recentEvents, isLoading } = useQuery<AnalyticsEvent[]>({
    queryKey: ["/api/dashboard/recent-activity"],
    retry: false,
  });

  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case "company_created":
        return Building;
      case "course_uploaded":
        return BookOpen;
      case "dispatch_created":
        return Send;
      default:
        return Activity;
    }
  };

  const getEventColor = (eventType: string) => {
    switch (eventType) {
      case "company_created":
        return "text-blue-600";
      case "course_uploaded":
        return "text-green-600";
      case "dispatch_created":
        return "text-purple-600";
      default:
        return "text-gray-600";
    }
  };

  const getEventDescription = (event: AnalyticsEvent) => {
    switch (event.eventType) {
      case "company_created":
        return `New company "${event.metadata?.name}" was created`;
      case "course_uploaded":
        return `Course "${event.metadata?.title}" was uploaded`;
      case "dispatch_created":
        return `Dispatch "${event.metadata?.title}" was created`;
      default:
        return `Event: ${event.eventType}`;
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return "Just now";
  };

  // Mock system alerts for demonstration
  const systemAlerts = [
    {
      id: 1,
      type: "warning",
      title: "License Usage Alert",
      description: "Innovation Labs is at 95% of their license limit",
      timestamp: new Date(Date.now() - 30 * 60000).toISOString(), // 30 minutes ago
    },
    {
      id: 2,
      type: "success",
      title: "Course Upload Complete",
      description: "Customer Service Excellence has been validated and is ready for dispatch",
      timestamp: new Date(Date.now() - 2 * 60 * 60000).toISOString(), // 2 hours ago
    },
    {
      id: 3,
      type: "info",
      title: "New Company Registration",
      description: "EduTech Partners has completed their registration and is pending approval",
      timestamp: new Date(Date.now() - 4 * 60 * 60000).toISOString(), // 4 hours ago
    },
  ];

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "warning":
        return AlertTriangle;
      case "success":
        return CheckCircle;
      case "info":
        return Info;
      default:
        return Info;
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case "warning":
        return "text-orange-600 bg-orange-50 border-orange-200";
      case "success":
        return "text-green-600 bg-green-50 border-green-200";
      case "info":
        return "text-blue-600 bg-blue-50 border-blue-200";
      default:
        return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Recent Dispatches */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
            <Send className="w-5 h-5 mr-2 text-blue-600" />
            Recent Platform Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded mb-1"></div>
                      <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {recentEvents?.slice(0, 4).map((event) => {
                const EventIcon = getEventIcon(event.eventType);
                const eventColor = getEventColor(event.eventType);
                
                return (
                  <div key={event.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 ${eventColor} bg-opacity-10 rounded-full flex items-center justify-center`}>
                        <EventIcon className={`w-4 h-4 ${eventColor}`} />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 text-sm">
                          {getEventDescription(event)}
                        </p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {event.eventType.replace("_", " ").toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center text-xs text-gray-500">
                      <Clock className="w-3 h-3 mr-1" />
                      {formatTimestamp(event.timestamp)}
                    </div>
                  </div>
                );
              })}
              {(!recentEvents || recentEvents.length === 0) && (
                <div className="text-center py-8 text-gray-500">
                  <Activity className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>No recent activity</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* System Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2 text-orange-600" />
            System Alerts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {systemAlerts.map((alert) => {
              const AlertIcon = getAlertIcon(alert.type);
              const alertStyles = getAlertColor(alert.type);
              
              return (
                <div key={alert.id} className={`flex items-start space-x-3 p-3 border rounded-lg ${alertStyles}`}>
                  <AlertIcon className="w-5 h-5 mt-0.5" />
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{alert.title}</p>
                    <p className="text-sm text-gray-600 mt-1">{alert.description}</p>
                    <div className="flex items-center text-xs text-gray-500 mt-2">
                      <Clock className="w-3 h-3 mr-1" />
                      {formatTimestamp(alert.timestamp)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
