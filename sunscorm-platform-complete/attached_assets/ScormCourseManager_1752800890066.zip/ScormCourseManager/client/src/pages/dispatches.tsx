import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Plus, 
  Search, 
  Send,
  Calendar,
  Users,
  ExternalLink,
  MoreVertical,
  Edit,
  Trash2,
  Eye
} from "lucide-react";

interface Dispatch {
  id: string;
  title: string;
  companyId: string;
  courseId: string;
  maxLearners?: number;
  currentLearners: number;
  expiresAt?: string;
  isActive: boolean;
  launchUrl?: string;
  createdAt: string;
  updatedAt: string;
}

interface Company {
  id: string;
  name: string;
}

interface Course {
  id: string;
  title: string;
  standard: string;
}

export default function Dispatches() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: dispatches, isLoading: dispatchesLoading } = useQuery<Dispatch[]>({
    queryKey: ["/api/dispatches"],
    retry: false,
  });

  const { data: companies } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
    retry: false,
  });

  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
    retry: false,
  });

  const createMutation = useMutation({
    mutationFn: async (dispatchData: any) => {
      await apiRequest("POST", "/api/dispatches", dispatchData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dispatches"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Success",
        description: "Dispatch created successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create dispatch",
        variant: "destructive",
      });
    },
  });

  const handleCreateDispatch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const dispatchData = {
      title: formData.get("title"),
      companyId: formData.get("companyId"),
      courseId: formData.get("courseId"),
      maxLearners: formData.get("maxLearners") ? parseInt(formData.get("maxLearners") as string) : null,
      expiresAt: formData.get("expiresAt") ? new Date(formData.get("expiresAt") as string).toISOString() : null,
      isActive: true,
    };

    createMutation.mutate(dispatchData);
  };

  // Filter dispatches based on search
  const filteredDispatches = dispatches?.filter(dispatch => 
    dispatch.title.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const getCompanyName = (companyId: string) => {
    return companies?.find(c => c.id === companyId)?.name || "Unknown Company";
  };

  const getCourseInfo = (courseId: string) => {
    const course = courses?.find(c => c.id === courseId);
    return course ? { title: course.title, standard: course.standard } : { title: "Unknown Course", standard: "" };
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getStatusBadge = (dispatch: Dispatch) => {
    if (!dispatch.isActive) {
      return <Badge variant="secondary">Inactive</Badge>;
    }
    
    if (dispatch.expiresAt && new Date(dispatch.expiresAt) < new Date()) {
      return <Badge variant="destructive">Expired</Badge>;
    }
    
    if (dispatch.maxLearners && dispatch.currentLearners >= dispatch.maxLearners) {
      return <Badge variant="outline" className="border-orange-500 text-orange-600">At Capacity</Badge>;
    }
    
    return <Badge variant="default" className="bg-green-100 text-green-700">Active</Badge>;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Layout>
      <div className="space-y-8">
        {/* Page Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Dispatch Management</h1>
            <p className="text-gray-600">Create and manage course dispatches for your companies</p>
          </div>
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                Create Dispatch
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle className="flex items-center">
                  <Send className="w-5 h-5 mr-2" />
                  Create New Dispatch
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateDispatch} className="space-y-4">
                <div>
                  <Label htmlFor="title">Dispatch Title</Label>
                  <Input 
                    id="title" 
                    name="title" 
                    placeholder="Enter dispatch title"
                    required 
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="companyId">Company</Label>
                  <Select name="companyId" required>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select company" />
                    </SelectTrigger>
                    <SelectContent>
                      {companies?.map((company) => (
                        <SelectItem key={company.id} value={company.id}>
                          {company.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="courseId">Course</Label>
                  <Select name="courseId" required>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select course" />
                    </SelectTrigger>
                    <SelectContent>
                      {courses?.map((course) => (
                        <SelectItem key={course.id} value={course.id}>
                          {course.title} ({course.standard.toUpperCase()})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="maxLearners">Max Learners (Optional)</Label>
                    <Input 
                      id="maxLearners" 
                      name="maxLearners" 
                      type="number"
                      placeholder="Unlimited"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="expiresAt">Expires At (Optional)</Label>
                    <Input 
                      id="expiresAt" 
                      name="expiresAt" 
                      type="date"
                      className="mt-1"
                    />
                  </div>
                </div>
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? "Creating..." : "Create Dispatch"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search dispatches..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Dispatches Grid */}
        {dispatchesLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-3 bg-gray-200 rounded"></div>
                    <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredDispatches.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDispatches.map((dispatch) => {
              const courseInfo = getCourseInfo(dispatch.courseId);
              return (
                <Card key={dispatch.id} className="hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg text-gray-900 mb-1">{dispatch.title}</CardTitle>
                        <p className="text-sm text-gray-600">{getCompanyName(dispatch.companyId)}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        {getStatusBadge(dispatch)}
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-1">Course</p>
                      <p className="text-sm text-gray-600">{courseInfo.title}</p>
                      {courseInfo.standard && (
                        <Badge variant="outline" className="mt-1 text-xs">
                          {courseInfo.standard.toUpperCase()}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500 mb-1">
                          <Users className="w-3 h-3 inline mr-1" />
                          Learners
                        </p>
                        <p className="font-medium">
                          {dispatch.currentLearners}
                          {dispatch.maxLearners && ` / ${dispatch.maxLearners}`}
                        </p>
                      </div>
                      
                      <div>
                        <p className="text-gray-500 mb-1">
                          <Calendar className="w-3 h-3 inline mr-1" />
                          Created
                        </p>
                        <p className="font-medium">{formatDate(dispatch.createdAt)}</p>
                      </div>
                    </div>

                    {dispatch.expiresAt && (
                      <div>
                        <p className="text-gray-500 text-sm mb-1">Expires</p>
                        <p className="text-sm font-medium">{formatDate(dispatch.expiresAt)}</p>
                      </div>
                    )}

                    <div className="flex space-x-2 pt-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Eye className="w-3 h-3 mr-1" />
                        View
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                      {dispatch.launchUrl && (
                        <Button variant="outline" size="sm">
                          <ExternalLink className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-xl">
            <Send className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No dispatches found</h3>
            <p className="text-gray-500 mb-6">
              {searchQuery 
                ? "Try adjusting your search query"
                : "Get started by creating your first dispatch"
              }
            </p>
            {!searchQuery && (
              <Button 
                onClick={() => setIsCreateDialogOpen(true)}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Dispatch
              </Button>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}
