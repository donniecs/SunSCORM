import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Layout from "@/components/Layout";
import MetricsCard from "@/components/MetricsCard";
import AnalyticsChart from "@/components/AnalyticsChart";
import RecentActivity from "@/components/RecentActivity";
import { useQuery } from "@tanstack/react-query";
import { 
  Building, 
  BookOpen, 
  Send, 
  PieChart,
  TrendingUp,
  Users,
  Award
} from "lucide-react";

interface DashboardMetrics {
  totalCompanies: number;
  totalCourses: number;
  monthlyDispatches: number;
  averageLicenseUsage: number;
  usageData: Array<{ date: string; dispatches: number; learners: number }>;
}

interface TopCompany {
  company: {
    id: string;
    name: string;
    logoUrl?: string;
  };
  dispatches: number;
  growth: number;
}

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: metrics, isLoading: metricsLoading } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard/metrics"],
    retry: false,
  });

  const { data: topCompanies, isLoading: companiesLoading } = useQuery<TopCompany[]>({
    queryKey: ["/api/dashboard/top-companies"],
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Layout>
      <div className="space-y-8">
        {/* Page Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Platform Overview</h1>
          <p className="text-gray-600">Monitor your SCORM content distribution and company performance</p>
        </div>

        {/* Key Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricsCard
            title="Total Companies"
            value={metrics?.totalCompanies?.toString() || "0"}
            change="+12%"
            changeType="positive"
            icon={Building}
            color="blue"
            loading={metricsLoading}
          />
          <MetricsCard
            title="Active Courses"
            value={metrics?.totalCourses?.toString() || "0"}
            change="+8%"
            changeType="positive"
            icon={BookOpen}
            color="green"
            loading={metricsLoading}
          />
          <MetricsCard
            title="Monthly Dispatches"
            value={metrics?.monthlyDispatches?.toString() || "0"}
            change="-3%"
            changeType="negative"
            icon={Send}
            color="orange"
            loading={metricsLoading}
          />
          <MetricsCard
            title="License Usage"
            value={`${metrics?.averageLicenseUsage || 0}%`}
            change="Average across all companies"
            changeType="neutral"
            icon={PieChart}
            color="red"
            loading={metricsLoading}
          />
        </div>

        {/* Analytics and Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Analytics Chart */}
          <div className="lg:col-span-2">
            <AnalyticsChart data={metrics?.usageData || []} loading={metricsLoading} />
          </div>

          {/* Top Performing Companies */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
              <Award className="w-5 h-5 mr-2 text-blue-600" />
              Top Performing Companies
            </h3>
            {companiesLoading ? (
              <div className="space-y-4">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-gray-200 rounded mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                      </div>
                      <div className="w-16 h-6 bg-gray-200 rounded"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {topCompanies?.map((item, index) => (
                  <div key={item.company.id} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center text-white font-medium">
                        {item.company.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{item.company.name}</p>
                        <p className="text-xs text-gray-500">{item.dispatches} dispatches</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-green-600 flex items-center">
                        <TrendingUp className="w-3 h-3 mr-1" />
                        +{item.growth}%
                      </p>
                      <div className="w-16 bg-gray-200 rounded-full h-2 mt-1">
                        <div 
                          className="bg-green-500 h-2 rounded-full transition-all duration-1000 ease-out" 
                          style={{ width: `${Math.min(item.growth * 2, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
                {(!topCompanies || topCompanies.length === 0) && (
                  <div className="text-center py-8 text-gray-500">
                    <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p>No company data available yet</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Recent Activity */}
        <RecentActivity />
      </div>
    </Layout>
  );
}
